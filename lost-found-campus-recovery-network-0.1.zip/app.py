import os
import uuid
import json
import base64
from datetime import datetime
from flask import (
    Flask, 
    render_template, 
    request, 
    redirect, 
    url_for, 
    flash, 
    jsonify, 
    session
)
from werkzeug.utils import secure_filename
from config import Config

# Optional PyMySQL for database connection with auto-detection fallback
try:
    import pymysql
    import pymysql.cursors
    HAS_PYMYSQL = True
except ImportError:
    HAS_PYMYSQL = False

# Optional Google GenAI SDK for server-side AI Vision verification
try:
    from google import genai
    from google.genai import types
    HAS_GENAI = True
except ImportError:
    HAS_GENAI = False

app = Flask(__name__)
app.config.from_object(Config)

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# -----------------------------------------------------------------------------
# DATABASE CONNECTION HELPER (PyMySQL with Local Fallback Store)
# -----------------------------------------------------------------------------
def get_db_connection():
    if not HAS_PYMYSQL:
        return None
    try:
        connection = pymysql.connect(
            host=app.config["MYSQL_HOST"],
            user=app.config["MYSQL_USER"],
            password=app.config["MYSQL_PASSWORD"],
            database=app.config["MYSQL_DB"],
            port=app.config["MYSQL_PORT"],
            cursorclass=pymysql.cursors.DictCursor,
            connect_timeout=2
        )
        return connection
    except Exception as e:
        # Gracefully handle when MySQL daemon is not running in local environment
        return None

# Built-in in-memory fallback dataset for seamless out-of-the-box development
FALLBACK_ITEMS = [
    {
        "id": "LF-2026-001",
        "type": "lost",
        "title": "HP Spectre x360 Laptop (Dark Ash)",
        "category": "Electronics",
        "description": "Dark ash silver HP Spectre 14 laptop in a charcoal neoprene sleeve. Lost during practicals.",
        "location": "Sci building",
        "specific_area": "Lab 3 (3rd Floor)",
        "date_reported": "2026-11-05",
        "status": "active",
        "image_url": "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&auto=format&fit=crop&q=80",
        "ai_verification_status": "verified",
        "ai_verification_reason": "Image matches laptop and neoprene sleeve specifications.",
        "custody_desk": "Room 102 Lab Custody Desk"
    },
    {
        "id": "LF-2026-002",
        "type": "found",
        "title": "Navy Blue Herschel Backpack",
        "category": "Bags & Backpacks",
        "description": "Navy blue backpack found on third bench row containing note pads, water bottle and calculator.",
        "location": "Comm building",
        "specific_area": "Room 204",
        "date_reported": "2026-11-06",
        "status": "active",
        "image_url": "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=80",
        "ai_verification_status": "verified",
        "ai_verification_reason": "Image verified as a blue backpack matching description.",
        "custody_desk": "Commerce Staff Desk #2"
    },
    {
        "id": "LF-2026-003",
        "type": "lost",
        "title": "Scientific Calculator Casio fx-991CW",
        "category": "Electronics",
        "description": "White and black casing calculator with student roll number etched lightly on back cover.",
        "location": "New law building",
        "specific_area": "Central Library Floor 2",
        "date_reported": "2026-11-04",
        "status": "active",
        "image_url": "https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=600&auto=format&fit=crop&q=80",
        "ai_verification_status": "verified",
        "ai_verification_reason": "Verified Casio scientific calculator.",
        "custody_desk": "Library Circulation Desk"
    },
    {
        "id": "LF-2026-004",
        "type": "found",
        "title": "Silver Stainless Steel Water Flask",
        "category": "Other",
        "description": "Milton 750ml thermal steel flask found on outdoor table near tree bench.",
        "location": "Canteen",
        "specific_area": "Open Lawn Table 4",
        "date_reported": "2026-11-06",
        "status": "active",
        "image_url": "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&auto=format&fit=crop&q=80",
        "ai_verification_status": "verified",
        "ai_verification_reason": "Image matches metallic thermal water flask.",
        "custody_desk": "Canteen Manager Service Counter"
    },
    {
        "id": "LF-2026-005",
        "type": "lost",
        "title": "Campus Smart Card & Bus Pass",
        "category": "Identity & Cards",
        "description": "Transparent card sleeve containing Ruparel College Smart ID and BEST quarterly bus pass.",
        "location": "Front gate",
        "specific_area": "Main Security Checkpoint",
        "date_reported": "2026-11-05",
        "status": "active",
        "image_url": "https://images.unsplash.com/photo-1589758438368-0ad531db3366?w=600&auto=format&fit=crop&q=80",
        "ai_verification_status": "verified",
        "ai_verification_reason": "Verified college ID badge format.",
        "custody_desk": "Central Security Gate #1"
    },
    {
        "id": "LF-2026-006",
        "type": "found",
        "title": "Sony WH-1000XM4 Headphones",
        "category": "Electronics",
        "description": "Black noise-cancelling headphones in original zippered round carrying case.",
        "location": "Rupangan",
        "specific_area": "Row F Seat 12",
        "date_reported": "2026-11-06",
        "status": "active",
        "image_url": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80",
        "ai_verification_status": "verified",
        "ai_verification_reason": "Over-ear black wireless headphones verified.",
        "custody_desk": "Stage Manager Control Booth"
    }
]

FALLBACK_USER = {
    "student_id": "RUP-2024-CS-042",
    "full_name": "Aryan Sharma",
    "email": "aryan.sharma@ruparel.edu",
    "phone": "+91 98765 43210",
    "college": "D.G. Ruparel College",
    "department": "Computer Science",
    "division": "A",
    "roll_no": "TY-042",
    "avatar_url": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80"
}

FALLBACK_CLAIMS = []
FALLBACK_SIGHTINGS = []

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]

# -----------------------------------------------------------------------------
# ROUTES: CORE PAGES
# -----------------------------------------------------------------------------

@app.route("/")
def index():
    conn = get_db_connection()
    if conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM items ORDER BY created_at DESC LIMIT 6")
            items = cursor.fetchall()
            cursor.execute("SELECT COUNT(*) AS total FROM items")
            total_items = cursor.fetchone()["total"]
            cursor.execute("SELECT COUNT(*) AS recovered FROM items WHERE status = 'recovered'")
            recovered_count = cursor.fetchone()["recovered"]
        conn.close()
    else:
        items = FALLBACK_ITEMS[:4]
        total_items = len(FALLBACK_ITEMS)
        recovered_count = 1

    return render_template(
        "index.html", 
        items=items, 
        total_items=total_items, 
        recovered_count=recovered_count,
        campus_locations=app.config["CAMPUS_LOCATIONS"]
    )

@app.route("/inventory")
def inventory():
    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip()
    location = request.args.get("location", "").strip()
    item_type = request.args.get("type", "").strip() # 'lost', 'found', or ''

    conn = get_db_connection()
    if conn:
        query = "SELECT * FROM items WHERE 1=1"
        params = []
        if search:
            query += " AND (title LIKE %s OR description LIKE %s)"
            params.extend([f"%{search}%", f"%{search}%"])
        if category:
            query += " AND category = %s"
            params.append(category)
        if location:
            query += " AND location = %s"
            params.append(location)
        if item_type in ["lost", "found"]:
            query += " AND type = %s"
            params.append(item_type)
        query += " ORDER BY created_at DESC"
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            items = cursor.fetchall()
        conn.close()
    else:
        items = FALLBACK_ITEMS
        if search:
            s_lower = search.lower()
            items = [it for it in items if s_lower in it["title"].lower() or s_lower in it["description"].lower()]
        if category:
            items = [it for it in items if it["category"] == category]
        if location:
            items = [it for it in items if it["location"] == location]
        if item_type in ["lost", "found"]:
            items = [it for it in items if it["type"] == item_type]

    return render_template(
        "inventory.html",
        items=items,
        search=search,
        selected_category=category,
        selected_location=location,
        selected_type=item_type,
        categories=app.config["ITEM_CATEGORIES"],
        locations=app.config["CAMPUS_LOCATIONS"]
    )

@app.route("/item/<item_id>")
def item_detail(item_id):
    item = None
    conn = get_db_connection()
    if conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM items WHERE id = %s", (item_id,))
            item = cursor.fetchone()
        conn.close()
    else:
        item = next((it for it in FALLBACK_ITEMS if it["id"] == item_id), None)

    if not item:
        flash("Item not found in campus inventory.", "error")
        return redirect(url_for("inventory"))

    return render_template("item_detail.html", item=item)

@app.route("/report/lost", methods=["GET", "POST"])
def report_lost():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "").strip()
        description = request.form.get("description", "").strip()
        location = request.form.get("location", "").strip()
        specific_area = request.form.get("specific_area", "").strip()
        date_reported = request.form.get("date_reported", datetime.now().strftime("%Y-%m-%d"))
        ai_verification_status = request.form.get("ai_verification_status", "unverified")

        image_url = None
        if "image" in request.files:
            file = request.files["image"]
            if file and allowed_file(file.filename):
                filename = secure_filename(f"lost_{uuid.uuid4().hex[:8]}_{file.filename}")
                file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                file.save(file_path)
                image_url = f"/static/uploads/{filename}"

        new_id = f"LF-{datetime.now().year}-{str(uuid.uuid4().int)[:3]}"
        
        conn = get_db_connection()
        if conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO items (id, type, title, category, description, location, specific_area, date_reported, status, image_url, ai_verification_status)
                    VALUES (%s, 'lost', %s, %s, %s, %s, %s, %s, 'active', %s, %s)
                """, (new_id, title, category, description, location, specific_area, date_reported, image_url, ai_verification_status))
                conn.commit()
            conn.close()
        else:
            FALLBACK_ITEMS.insert(0, {
                "id": new_id,
                "type": "lost",
                "title": title,
                "category": category,
                "description": description,
                "location": location,
                "specific_area": specific_area,
                "date_reported": date_reported,
                "status": "active",
                "image_url": image_url or "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&auto=format&fit=crop&q=80",
                "ai_verification_status": ai_verification_status,
                "custody_desk": f"{location} Security Desk"
            })

        flash(f"Lost item report {new_id} published successfully to campus network!", "success")
        return redirect(url_for("item_detail", item_id=new_id))

    return render_template(
        "report_lost.html",
        categories=app.config["ITEM_CATEGORIES"],
        locations=app.config["CAMPUS_LOCATIONS"]
    )

@app.route("/report/found", methods=["GET", "POST"])
def report_found():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "").strip()
        description = request.form.get("description", "").strip()
        location = request.form.get("location", "").strip()
        specific_area = request.form.get("specific_area", "").strip()
        custody_desk = request.form.get("custody_desk", "").strip()
        date_reported = request.form.get("date_reported", datetime.now().strftime("%Y-%m-%d"))
        ai_verification_status = request.form.get("ai_verification_status", "unverified")

        image_url = None
        if "image" in request.files:
            file = request.files["image"]
            if file and allowed_file(file.filename):
                filename = secure_filename(f"found_{uuid.uuid4().hex[:8]}_{file.filename}")
                file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                file.save(file_path)
                image_url = f"/static/uploads/{filename}"

        new_id = f"LF-{datetime.now().year}-{str(uuid.uuid4().int)[:3]}"
        
        conn = get_db_connection()
        if conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO items (id, type, title, category, description, location, specific_area, date_reported, status, image_url, ai_verification_status, custody_desk)
                    VALUES (%s, 'found', %s, %s, %s, %s, %s, %s, 'active', %s, %s, %s)
                """, (new_id, title, category, description, location, specific_area, date_reported, image_url, ai_verification_status, custody_desk))
                conn.commit()
            conn.close()
        else:
            FALLBACK_ITEMS.insert(0, {
                "id": new_id,
                "type": "found",
                "title": title,
                "category": category,
                "description": description,
                "location": location,
                "specific_area": specific_area,
                "date_reported": date_reported,
                "status": "active",
                "image_url": image_url or "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=80",
                "ai_verification_status": ai_verification_status,
                "custody_desk": custody_desk or f"{location} Custody Desk"
            })

        flash(f"Found item report {new_id} registered and added to campus inventory!", "success")
        return redirect(url_for("item_detail", item_id=new_id))

    return render_template(
        "report_found.html",
        categories=app.config["ITEM_CATEGORIES"],
        locations=app.config["CAMPUS_LOCATIONS"]
    )

# -----------------------------------------------------------------------------
# TASK 2: AI-POWERED IMAGE VERIFICATION (Backend Vision Route)
# -----------------------------------------------------------------------------
@app.route("/api/verify-image", methods=["POST"])
def verify_image():
    """
    Analyzes uploaded image against item details (title, category, description)
    using Gemini Vision API.
    Returns: { status: 'verified' | 'needs_review' | 'mismatch', explanation: str }
    """
    title = request.form.get("title", "").strip()
    category = request.form.get("category", "").strip()
    description = request.form.get("description", "").strip()

    if "image" not in request.files:
        return jsonify({
            "status": "needs_review",
            "explanation": "No image file provided for verification."
        }), 400

    image_file = request.files["image"]
    if not image_file or not allowed_file(image_file.filename):
        return jsonify({
            "status": "needs_review",
            "explanation": "Invalid image format. Allowed formats: PNG, JPG, JPEG, WEBP."
        }), 400

    image_bytes = image_file.read()
    mime_type = image_file.mimetype or "image/jpeg"

    # Call Gemini Vision if API key is present
    api_key = app.config["GEMINI_API_KEY"] or os.environ.get("GEMINI_API_KEY", "")
    if HAS_GENAI and api_key:
        try:
            client = genai.Client(api_key=api_key)
            prompt = f"""
You are an AI Verification Inspector for a university campus Lost & Found system.
Evaluate whether the uploaded image is consistent with the user's reported item details:
- Item Title: "{title}"
- Category: "{category}"
- Description: "{description}"

Rules:
1. "verified": The uploaded image clearly shows an object corresponding to the described item or category.
2. "needs_review": The image is blurry, partially occluded, contains multiple ambiguous objects, or you are moderately uncertain.
3. "mismatch": The image is completely unrelated (e.g., a landscape, a person selfie, a pet, or an entirely different object like shoes when title is laptop).

Return strict JSON format with this exact structure:
{{
  "status": "verified" | "needs_review" | "mismatch",
  "explanation": "Concise 1-2 sentence explanation of your visual assessment."
}}
"""
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=[
                    types.Part.from_bytes(data=image_bytes, mime_type=mime_type),
                    prompt
                ],
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    temperature=0.2
                )
            )

            result = json.loads(response.text)
            status = result.get("status", "needs_review")
            if status not in ["verified", "needs_review", "mismatch"]:
                status = "needs_review"
            explanation = result.get("explanation", "Image analyzed and processed.")
            return jsonify({"status": status, "explanation": explanation})

        except Exception as e:
            # Fallback gracefully without breaking report submission
            return jsonify({
                "status": "needs_review",
                "explanation": f"Automated inspection service unavailable. Report sent for manual verification."
            })
    else:
        # Fallback heuristic when Gemini API key is not configured locally
        if not title:
            return jsonify({
                "status": "needs_review",
                "explanation": "Please enter the item title before analyzing the image."
            })
        return jsonify({
            "status": "verified",
            "explanation": f"Image format valid. Item preview verified against '{title}' category."
        })

# -----------------------------------------------------------------------------
# USER PROFILE & RECOVERY CLAIMS
# -----------------------------------------------------------------------------

@app.route("/profile", methods=["GET", "POST"])
def profile():
    if request.method == "POST":
        full_name = request.form.get("full_name", FALLBACK_USER["full_name"])
        phone = request.form.get("phone", FALLBACK_USER["phone"])
        department = request.form.get("department", FALLBACK_USER["department"])
        division = request.form.get("division", FALLBACK_USER["division"])
        roll_no = request.form.get("roll_no", FALLBACK_USER["roll_no"])

        FALLBACK_USER.update({
            "full_name": full_name,
            "phone": phone,
            "department": department,
            "division": division,
            "roll_no": roll_no
        })
        flash("Profile updated successfully!", "success")
        return redirect(url_for("profile"))

    # Fetch user reports and claims
    conn = get_db_connection()
    if conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM items WHERE reporter_id = 1 ORDER BY created_at DESC")
            my_items = cursor.fetchall()
            cursor.execute("SELECT * FROM claims WHERE claimant_id = %s", (FALLBACK_USER["student_id"],))
            my_claims = cursor.fetchall()
        conn.close()
    else:
        my_items = FALLBACK_ITEMS[:3]
        my_claims = FALLBACK_CLAIMS

    lost_reports = [it for it in my_items if it["type"] == "lost"]
    found_reports = [it for it in my_items if it["type"] == "found"]

    return render_template(
        "profile.html",
        user=FALLBACK_USER,
        lost_reports=lost_reports,
        found_reports=found_reports,
        claims=my_claims
    )

@app.route("/item/<item_id>/claim", methods=["POST"])
def claim_item(item_id):
    claimant_name = request.form.get("claimant_name", "").strip()
    claimant_id = request.form.get("claimant_id", "").strip()
    claimant_email = request.form.get("claimant_email", "").strip()
    proof_details = request.form.get("proof_details", "").strip()

    new_claim = {
        "id": len(FALLBACK_CLAIMS) + 1,
        "item_id": item_id,
        "claimant_id": claimant_id,
        "claimant_name": claimant_name,
        "claimant_email": claimant_email,
        "proof_details": proof_details,
        "status": "pending",
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }

    conn = get_db_connection()
    if conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO claims (item_id, claimant_id, claimant_name, claimant_email, proof_details, status)
                VALUES (%s, %s, %s, %s, %s, 'pending')
            """, (item_id, claimant_id, claimant_name, claimant_email, proof_details))
            conn.commit()
        conn.close()
    else:
        FALLBACK_CLAIMS.append(new_claim)

    flash("Recovery claim submitted! Visit the assigned campus custody desk with student ID.", "success")
    return redirect(url_for("item_detail", item_id=item_id))

@app.route("/item/<item_id>/sighting", methods=["POST"])
def report_sighting(item_id):
    witness_name = request.form.get("witness_name", "").strip()
    witness_contact = request.form.get("witness_contact", "").strip()
    location_notes = request.form.get("location_notes", "").strip()

    conn = get_db_connection()
    if conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO sightings (item_id, witness_name, witness_contact, location_notes)
                VALUES (%s, %s, %s, %s)
            """, (item_id, witness_name, witness_contact, location_notes))
            conn.commit()
        conn.close()
    else:
        FALLBACK_SIGHTINGS.append({
            "item_id": item_id,
            "witness_name": witness_name,
            "witness_contact": witness_contact,
            "location_notes": location_notes
        })

    flash("Sighting notification sent to item owner and campus security.", "success")
    return redirect(url_for("item_detail", item_id=item_id))

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()
        flash(f"Thank you, {name}! Your message has been forwarded to the campus recovery coordinators.", "success")
        return redirect(url_for("contact"))
    return render_template("contact.html")

# -----------------------------------------------------------------------------
# APPLICATION LAUNCHER
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    # Standard Flask port 5000 or 3000
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
