import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "lost-found-campus-recovery-network-secret-key-2026")
    
    # MySQL Database Configuration
    MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_USER = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
    MYSQL_DB = os.getenv("MYSQL_DB", "lost_and_found_db")
    MYSQL_PORT = int(os.getenv("MYSQL_PORT", 3306))
    
    # File Upload Configuration
    UPLOAD_FOLDER = os.path.join(os.path.abspath(os.path.dirname(__file__)), "static", "uploads")
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5 MB maximum file size
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
    
    # Gemini AI Vision Configuration
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    
    # Campus Locations (DG Ruparel College - 10 Monitored Buildings)
    CAMPUS_LOCATIONS = [
        "Sci building",
        "Comm building",
        "Arts building",
        "Canteen",
        "Rupangan",
        "Black facility building",
        "New law building",
        "Front gate",
        "Backgate",
        "Garden"
    ]
    
    # Categories
    ITEM_CATEGORIES = [
        "Electronics",
        "Identity & Cards",
        "Bags & Backpacks",
        "Books & Stationery",
        "Keys & Accessories",
        "Clothing & Wearables",
        "Other"
    ]
