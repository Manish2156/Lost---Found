-- ========================================================
-- LOST & FOUND – CAMPUS RECOVERY NETWORK
-- MySQL Database Schema
-- Compatible with MySQL 5.7+ / 8.0+
-- ========================================================

CREATE DATABASE IF NOT EXISTS lost_and_found_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lost_and_found_db;

-- 1. USERS / STUDENTS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(30) NULL,
    college VARCHAR(150) NOT NULL DEFAULT 'D.G. Ruparel College',
    department VARCHAR(100) NOT NULL DEFAULT 'Computer Science',
    division VARCHAR(10) NOT NULL DEFAULT 'A',
    roll_no VARCHAR(20) NOT NULL DEFAULT 'TY-042',
    avatar_url VARCHAR(255) NULL DEFAULT '/static/images/default_avatar.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. LOST & FOUND ITEMS TABLE
CREATE TABLE IF NOT EXISTS items (
    id VARCHAR(50) PRIMARY KEY,
    type ENUM('lost', 'found') NOT NULL,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(60) NOT NULL,
    description TEXT NOT NULL,
    location ENUM(
        'Sci building',
        'Comm building',
        'Arts building',
        'Canteen',
        'Rupangan',
        'Black facility building',
        'New law building',
        'Front gate',
        'Backgate',
        'Garden'
    ) NOT NULL,
    specific_area VARCHAR(150) NULL,
    date_reported DATE NOT NULL,
    time_reported TIME NULL,
    status ENUM('active', 'claimed', 'recovered', 'pending_review') NOT NULL DEFAULT 'active',
    image_url VARCHAR(255) NULL,
    ai_verification_status ENUM('verified', 'needs_review', 'mismatch', 'unverified') DEFAULT 'unverified',
    ai_verification_reason TEXT NULL,
    reporter_id INT NULL,
    custody_desk VARCHAR(150) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 3. CLAIMS TABLE
CREATE TABLE IF NOT EXISTS claims (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id VARCHAR(50) NOT NULL,
    claimant_id VARCHAR(50) NOT NULL,
    claimant_name VARCHAR(120) NOT NULL,
    claimant_email VARCHAR(120) NOT NULL,
    claimant_phone VARCHAR(30) NULL,
    proof_details TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. SIGHTINGS / NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS sightings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id VARCHAR(50) NOT NULL,
    witness_name VARCHAR(120) NOT NULL,
    witness_contact VARCHAR(120) NOT NULL,
    location_notes TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ========================================================
-- SEED INITIAL MOCK DATA
-- ========================================================

INSERT INTO users (id, student_id, full_name, email, phone, college, department, division, roll_no)
VALUES 
(1, 'RUP-2024-CS-042', 'Aryan Sharma', 'aryan.sharma@ruparel.edu', '+91 98765 43210', 'D.G. Ruparel College', 'Computer Science', 'A', 'TY-042')
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);

INSERT INTO items (id, type, title, category, description, location, specific_area, date_reported, status, image_url, ai_verification_status, reporter_id, custody_desk)
VALUES
('LF-2026-001', 'lost', 'HP Spectre x360 Laptop (Dark Ash)', 'Electronics', 'Dark ash silver HP Spectre 14 laptop in a charcoal neoprene sleeve. Lost during practicals.', 'Sci building', 'Lab 3 (3rd Floor)', '2026-11-05', 'active', 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&auto=format&fit=crop&q=80', 'verified', 1, 'Room 102 Lab Custody Desk'),
('LF-2026-002', 'found', 'Navy Blue Herschel Backpack', 'Bags & Backpacks', 'Navy blue backpack found on third bench row containing note pads, water bottle and calculator.', 'Comm building', 'Room 204', '2026-11-06', 'active', 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=80', 'verified', 1, 'Commerce Staff Desk #2'),
('LF-2026-003', 'lost', 'Scientific Calculator Casio fx-991CW', 'Electronics', 'White and black casing calculator with student roll number etched lightly on back cover.', 'New law building', 'Central Library Floor 2', '2026-11-04', 'active', 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=600&auto=format&fit=crop&q=80', 'verified', 1, 'Library Circulation Desk'),
('LF-2026-004', 'found', 'Silver Stainless Steel Water Flask', 'Other', 'Milton 750ml thermal steel flask found on outdoor table near tree bench.', 'Canteen', 'Open Lawn Table 4', '2026-11-06', 'active', 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&auto=format&fit=crop&q=80', 'verified', 1, 'Canteen Manager Service Counter'),
('LF-2026-005', 'lost', 'Campus Smart Card & Bus Pass', 'Identity & Cards', 'Transparent card sleeve containing Ruparel College Smart ID and BEST quarterly bus pass.', 'Front gate', 'Main Security Checkpoint', '2026-11-05', 'active', 'https://images.unsplash.com/photo-1589758438368-0ad531db3366?w=600&auto=format&fit=crop&q=80', 'verified', 1, 'Central Security Gate #1'),
('LF-2026-006', 'found', 'Sony WH-1000XM4 Headphones', 'Electronics', 'Black noise-cancelling headphones in original zippered round carrying case.', 'Rupangan', 'Row F Seat 12', '2026-11-06', 'active', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80', 'verified', 1, 'Stage Manager Control Booth')
ON DUPLICATE KEY UPDATE title=VALUES(title);
