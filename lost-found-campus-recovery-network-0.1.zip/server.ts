import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // JSON Body parsing with 10MB limit for image base64 data
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Initialize Gemini Client
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Simulated Persistent In-Memory Student Profile Store (Pre-configured for student integration)
  let currentProfile = {
    id: 'STU-2026-8842',
    name: 'Raj Vishwakarma',
    email: 'raj.vishwakarma@campus.edu',
    studentId: 'STU-884291',
    college: 'Campus College of Science & Arts',
    department: 'Computer Engineering & Technology',
    division: 'Div A',
    rollNumber: 'CE-42',
    phone: '+91 98765 43210',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    bio: 'Third-year engineering student. Tech enthusiast & campus recovery volunteer.',
    joinedDate: 'August 2024',
    status: 'Active Student'
  };

  // Mock User Reports & Recovery Requests for this student
  let userReports = [
    {
      id: 'LF-2026-9041',
      title: 'Boat Rockerz 450 Bluetooth Headphones',
      type: 'lost' as const,
      category: 'Electronics',
      location: 'Sci building',
      dateReported: 'Yesterday at 3:30 PM',
      status: 'Pending' as const,
      description: 'Matte black finish with slight scratch on left hinge.',
      imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
      aiVerificationStatus: 'verified' as const,
      aiExplanation: 'Image matched black wireless over-ear headphones.'
    },
    {
      id: 'LF-2026-8812',
      title: 'Graphing Calculator (TI-84 Plus CE)',
      type: 'lost' as const,
      category: 'Electronics',
      location: 'Comm building',
      dateReported: '4 days ago',
      status: 'Approved' as const,
      description: 'Blue casing with sticker on the battery cover.',
      imageUrl: 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?auto=format&fit=crop&w=600&q=80',
      aiVerificationStatus: 'verified' as const,
      aiExplanation: 'Image verified as scientific graphing calculator.'
    },
    {
      id: 'LF-2026-7734',
      title: 'Casio Vintage Digital Watch (Silver)',
      type: 'found' as const,
      category: 'Jewelry & Accessories',
      location: 'Canteen',
      dateReported: '1 week ago',
      status: 'Recovered' as const,
      description: 'Found on table 4 near the refreshment counter.',
      imageUrl: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80',
      aiVerificationStatus: 'verified' as const,
      aiExplanation: 'Image verified as metallic silver wristwatch.'
    }
  ];

  let userClaims = [
    {
      id: 'CLM-2026-104',
      itemId: 'LF-2026-8812',
      itemTitle: 'Graphing Calculator (TI-84 Plus CE)',
      location: 'Comm building',
      requestDate: '3 days ago',
      status: 'Approved' as const,
      pickupLocation: 'Front gate security office',
      instructions: 'Please bring your valid student ID card for physical custody verification.'
    },
    {
      id: 'CLM-2026-108',
      itemId: 'LF-2026-9041',
      itemTitle: 'Boat Rockerz 450 Bluetooth Headphones',
      location: 'Sci building',
      requestDate: 'Yesterday',
      status: 'Pending' as const,
      pickupLocation: 'Sci building custody desk',
      instructions: 'Staff is currently verifying serial details with the finder.'
    }
  ];

  // ==========================================
  // API: User Profile & Reports Endpoints
  // ==========================================
  app.get('/api/user/profile', (_req, res) => {
    res.json({
      success: true,
      profile: currentProfile,
      reports: userReports,
      claims: userClaims
    });
  });

  app.put('/api/user/profile', (req, res) => {
    const updates = req.body;
    currentProfile = {
      ...currentProfile,
      ...updates
    };
    res.json({
      success: true,
      message: 'Profile updated successfully',
      profile: currentProfile
    });
  });

  // ==========================================
  // API: AI-Powered Image Verification Endpoint
  // ==========================================
  app.post('/api/verify-image', async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg', title, category, description } = req.body;

      if (!imageBase64) {
        return res.status(400).json({
          success: false,
          error: 'Image data is required for verification.'
        });
      }

      // Validate allowed mime types
      const allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
      if (!allowedMimes.includes(mimeType)) {
        return res.status(400).json({
          success: false,
          error: `Unsupported image format (${mimeType}). Please upload JPG, PNG, or WEBP.`
        });
      }

      // Fallback if no GEMINI_API_KEY is configured in environment
      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          success: true,
          status: 'needs_review',
          confidenceScore: 70,
          detectedObject: 'Item detected (Visual validation service offline)',
          explanation: 'AI vision backend is operating in manual moderation mode. Your report will be inspected by campus staff.',
          recommendation: 'Manual staff review required'
        });
      }

      // Strip data URL prefix if provided
      const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');

      const promptText = `
You are an expert AI vision verification auditor for a university Lost & Found platform.
Your task is to analyze the uploaded image and cross-verify it against the user's reported item details:
- Claimed Title: "${title || 'Not specified'}"
- Category: "${category || 'General'}"
- User Description: "${description || 'None'}"

Evaluate:
1. What object or scene is visible in this photo?
2. Does the image depict an actual physical item consistent with the claimed title and description?
3. Check for obvious mismatches (e.g. user claims "Fastrack Watch" but image is a shoe, a landscape, a cartoon, food, a blank screen, or an unrelated meme).
4. Check for ambiguous/uncertain images (e.g. extremely blurry, partial view, or low lighting).

Classify the verification result into one of these strict statuses:
- "verified": The image clearly and plausibly depicts the claimed item or category.
- "needs_review": The image is blurry, ambiguous, or the AI has low confidence.
- "mismatch": The image clearly depicts an entirely different object, animal, person, or irrelevant content that contradicts the report.

Assign a confidence score between 0 and 100.
Provide a clear, objective explanation in 1-2 concise sentences.
Provide a helpful recommendation for the student or moderator.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: cleanBase64,
              },
            },
            {
              text: promptText,
            },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              status: {
                type: Type.STRING,
                description: 'Must be one of: verified, needs_review, mismatch',
              },
              detectedObject: {
                type: Type.STRING,
                description: 'Brief description of the primary object detected in the image',
              },
              confidenceScore: {
                type: Type.INTEGER,
                description: 'Confidence score from 0 to 100',
              },
              explanation: {
                type: Type.STRING,
                description: 'Clear, user-friendly 1-2 sentence explanation of the verification decision',
              },
              recommendation: {
                type: Type.STRING,
                description: 'Brief recommendation for the student or moderator',
              },
            },
            required: ['status', 'detectedObject', 'confidenceScore', 'explanation'],
          },
        },
      });

      const parsedResult = JSON.parse(response.text || '{}');
      
      // Ensure status is strictly one of the 3 values
      let finalStatus: 'verified' | 'needs_review' | 'mismatch' = 'needs_review';
      if (['verified', 'needs_review', 'mismatch'].includes(parsedResult.status)) {
        finalStatus = parsedResult.status as 'verified' | 'needs_review' | 'mismatch';
      }

      return res.json({
        success: true,
        status: finalStatus,
        detectedObject: parsedResult.detectedObject || 'Physical item',
        confidenceScore: parsedResult.confidenceScore || 85,
        explanation: parsedResult.explanation || 'Image evaluated successfully.',
        recommendation: parsedResult.recommendation || (finalStatus === 'verified' ? 'Proceed with report' : 'Review image')
      });
    } catch (err: any) {
      console.error('Error during AI image verification:', err);
      return res.json({
        success: true,
        status: 'needs_review',
        confidenceScore: 50,
        detectedObject: 'Item detected (Verification fallback)',
        explanation: 'AI vision check could not be completed automatically. Report will undergo manual staff review.',
        recommendation: 'Manual staff review required'
      });
    }
  });

  // Mount Vite middlewares in development or serve static in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Lost & Found Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
