import React, { useState, useEffect, useRef } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  Building2, 
  GraduationCap, 
  Calendar, 
  ShieldCheck, 
  Edit3, 
  Camera, 
  LogOut, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  ArrowUpRight, 
  MapPin, 
  FileText, 
  AlertTriangle,
  Upload,
  X,
  Share2
} from 'lucide-react';
import { UserProfile, UserReportItem, UserRecoveryRequest, ReportApprovalStatus } from '../types';
import { getStudentProfile, updateStudentProfile, logoutUser } from '../services/authIntegration';

interface ProfileDashboardProps {
  onNavigateToReport: (type: 'lost') => void;
  onNavigateToInventory: () => void;
  onShowToast: (msg: string) => void;
  onLogout: () => void;
}

export const ProfileDashboard: React.FC<ProfileDashboardProps> = ({
  onNavigateToReport,
  onNavigateToInventory,
  onShowToast,
  onLogout
}) => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [reports, setReports] = useState<UserReportItem[]>([]);
  const [claims, setClaims] = useState<UserRecoveryRequest[]>([]);
  const [loading, setLoading] = useState(true);

  // Active view tab inside profile: 'lost' | 'found' | 'claims'
  const [activeSection, setActiveSection] = useState<'lost' | 'found' | 'claims'>('lost');

  // Edit Profile Modal State
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editForm, setEditForm] = useState<Partial<UserProfile>>({});
  const [savingProfile, setSavingProfile] = useState(false);

  // Logout confirmation modal
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);

  // Avatar upload ref
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // Load profile data on mount
  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const data = await getStudentProfile();
        setProfile(data.profile);
        setReports(data.reports);
        setClaims(data.claims);
        setEditForm(data.profile);
      } catch (err) {
        console.error('Failed to load profile', err);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Handle avatar upload & preview
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      onShowToast('Please select a valid image file (PNG, JPG, WEBP).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      onShowToast('Profile photo size should be under 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Url = reader.result as string;
      if (profile) {
        const updated = await updateStudentProfile({ avatarUrl: base64Url });
        setProfile(updated);
        onShowToast('Profile picture updated successfully!');
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle Edit Profile Save
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setSavingProfile(true);

    try {
      const updated = await updateStudentProfile(editForm);
      setProfile(updated);
      setEditModalOpen(false);
      onShowToast('Profile information saved successfully.');
    } catch (err) {
      onShowToast('Failed to save profile. Changes kept locally.');
    } finally {
      setSavingProfile(false);
    }
  };

  // Handle Logout Confirmation
  const handleConfirmLogout = () => {
    logoutUser();
    setLogoutModalOpen(false);
    onShowToast('You have been logged out of your campus session.');
    onLogout();
  };

  // Filtered reports
  const myLostReports = reports.filter((r) => r.type === 'lost');
  const myFoundReports = reports.filter((r) => r.type === 'found');

  // Render Status Badge
  const renderStatusBadge = (status: ReportApprovalStatus) => {
    switch (status) {
      case 'Approved':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Approved &amp; Live</span>
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Pending Moderation</span>
          </span>
        );
      case 'Recovered':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Recovered / Handed Over</span>
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            <span>Rejected / Duplicate</span>
          </span>
        );
      default:
        return null;
    }
  };

  if (loading || !profile) {
    return (
      <div className="flex items-center justify-center p-12 text-[#153931]">
        <div className="w-8 h-8 border-3 border-[#153931] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-7 animate-in fade-in duration-200 pb-8">
      
      {/* ========================================================
          1. HEADER PROFILE HERO CARD
         ======================================================== */}
      <div className="relative bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs overflow-hidden">
        
        {/* Decorative subtle background gradient accents */}
        <div className="absolute top-0 left-0 right-0 h-28 bg-gradient-to-r from-[#112923] via-[#1a4a3f] to-[#256356] opacity-95" />
        
        <div className="relative pt-10 sm:pt-12 flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
          
          {/* Avatar and Primary Identity */}
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
            
            {/* Avatar with Upload Badge */}
            <div className="relative group shrink-0">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden border-4 border-white shadow-md bg-slate-100 flex items-center justify-center">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={profile.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-12 h-12 text-slate-400" />
                )}
              </div>
              
              {/* Camera Upload Button */}
              <button
                type="button"
                onClick={() => avatarInputRef.current?.click()}
                className="absolute -bottom-1 -right-1 p-2 bg-[#112923] hover:bg-[#1c473c] text-white rounded-xl shadow-md border-2 border-white transition-transform active:scale-95 cursor-pointer"
                title="Change Profile Photo"
                aria-label="Change Profile Photo"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
              <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
              />
            </div>

            {/* Name, Student ID & Verified Student Pill */}
            <div className="space-y-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#112a24] font-display tracking-tight">
                  {profile.name}
                </h1>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#eef7ec] text-[#1c483c] border border-[#cbe5c6]">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#246352]" />
                  <span>Verified Student</span>
                </span>
              </div>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-slate-500">
                <span className="font-mono font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                  ID: {profile.studentId}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>{profile.email}</span>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{profile.phone}</span>
                </span>
              </div>
            </div>

          </div>

          {/* Action Buttons: Edit Profile & Logout */}
          <div className="flex items-center gap-2.5 self-center sm:self-end w-full sm:w-auto justify-center sm:justify-end">
            <button
              onClick={() => {
                setEditForm(profile);
                setEditModalOpen(true);
              }}
              className="px-4 py-2 text-xs font-semibold text-[#112923] bg-[#eef4ec] hover:bg-[#dce9d8] border border-[#d2e2cf] rounded-xl transition-all shadow-2xs hover:shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Profile</span>
            </button>

            <button
              onClick={() => setLogoutModalOpen(true)}
              className="px-4 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>

        </div>

        {/* Academic Details Strip */}
        <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="space-y-0.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              College
            </span>
            <span className="font-bold text-slate-800 block truncate" title={profile.college}>
              {profile.college}
            </span>
          </div>

          <div className="space-y-0.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Department
            </span>
            <span className="font-bold text-slate-800 block truncate" title={profile.department}>
              {profile.department}
            </span>
          </div>

          <div className="space-y-0.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Division &amp; Roll
            </span>
            <span className="font-bold text-slate-800 block">
              {profile.division} • Roll #{profile.rollNumber}
            </span>
          </div>

          <div className="space-y-0.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Status &amp; Batch
            </span>
            <span className="font-bold text-slate-800 block">
              {profile.status} (Joined {profile.joinedDate})
            </span>
          </div>
        </div>

      </div>

      {/* ========================================================
          2. ACTIVITY STATS SUMMARY CARDS
         ======================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Stat 1: My Lost Reports */}
        <div 
          onClick={() => setActiveSection('lost')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeSection === 'lost'
              ? 'bg-[#112923] text-white border-[#112923] shadow-md'
              : 'bg-white text-slate-800 border-slate-200/80 hover:border-slate-300 shadow-2xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold ${activeSection === 'lost' ? 'text-[#c2eb8c]' : 'text-slate-500'}`}>
              My Lost Reports
            </span>
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${activeSection === 'lost' ? 'bg-white/10 text-white' : 'bg-slate-100 text-slate-600'}`}>
              <FileText className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display">{myLostReports.length}</span>
            <span className={`text-[11px] ${activeSection === 'lost' ? 'text-[#9fc7bc]' : 'text-slate-400'}`}>
              reported items
            </span>
          </div>
        </div>

        {/* Stat 2: My Found Reports */}
        <div 
          onClick={() => setActiveSection('found')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeSection === 'found'
              ? 'bg-[#112923] text-white border-[#112923] shadow-md'
              : 'bg-white text-slate-800 border-slate-200/80 hover:border-slate-300 shadow-2xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold ${activeSection === 'found' ? 'text-[#c2eb8c]' : 'text-slate-500'}`}>
              My Found Reports
            </span>
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${activeSection === 'found' ? 'bg-white/10 text-white' : 'bg-slate-100 text-slate-600'}`}>
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display">{myFoundReports.length}</span>
            <span className={`text-[11px] ${activeSection === 'found' ? 'text-[#9fc7bc]' : 'text-slate-400'}`}>
              turned in items
            </span>
          </div>
        </div>

        {/* Stat 3: My Recovery Requests */}
        <div 
          onClick={() => setActiveSection('claims')}
          className={`p-5 rounded-2xl border transition-all cursor-pointer ${
            activeSection === 'claims'
              ? 'bg-[#112923] text-white border-[#112923] shadow-md'
              : 'bg-white text-slate-800 border-slate-200/80 hover:border-slate-300 shadow-2xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold ${activeSection === 'claims' ? 'text-[#c2eb8c]' : 'text-slate-500'}`}>
              My Recovery Requests
            </span>
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${activeSection === 'claims' ? 'bg-white/10 text-white' : 'bg-slate-100 text-slate-600'}`}>
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-display">{claims.length}</span>
            <span className={`text-[11px] ${activeSection === 'claims' ? 'text-[#9fc7bc]' : 'text-slate-400'}`}>
              active claims
            </span>
          </div>
        </div>

      </div>

      {/* ========================================================
          3. TAB CONTENT: REPORTS & RECOVERY REQUESTS
         ======================================================== */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-5">
        
        {/* Navigation Tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl w-fit">
            <button
              onClick={() => setActiveSection('lost')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeSection === 'lost'
                  ? 'bg-white text-[#112923] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              My Lost Reports ({myLostReports.length})
            </button>
            <button
              onClick={() => setActiveSection('found')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeSection === 'found'
                  ? 'bg-white text-[#112923] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              My Found Reports ({myFoundReports.length})
            </button>
            <button
              onClick={() => setActiveSection('claims')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeSection === 'claims'
                  ? 'bg-white text-[#112923] shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              My Recovery Requests ({claims.length})
            </button>
          </div>

          {/* Quick Action Button */}
          <div>
            {activeSection === 'lost' && (
              <button
                onClick={() => onNavigateToReport('lost')}
                className="px-4 py-2 text-xs font-bold text-white bg-[#112923] hover:bg-[#1a4037] rounded-xl transition-all shadow-xs"
              >
                + Report New Lost Item
              </button>
            )}
            {activeSection === 'found' && (
              <button
                onClick={onNavigateToInventory}
                className="px-4 py-2 text-xs font-bold text-[#112923] bg-[#c2eb8c] hover:bg-[#b0df73] rounded-xl transition-all shadow-xs"
              >
                Browse Campus Inventory
              </button>
            )}
            {activeSection === 'claims' && (
              <button
                onClick={onNavigateToInventory}
                className="px-4 py-2 text-xs font-bold text-[#112923] bg-[#c2eb8c] hover:bg-[#b0df73] rounded-xl transition-all shadow-xs"
              >
                Find &amp; Claim Item
              </button>
            )}
          </div>
        </div>

        {/* SECTION 1: MY LOST REPORTS */}
        {activeSection === 'lost' && (
          <div className="space-y-4">
            {myLostReports.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myLostReports.map((report) => (
                  <div
                    key={report.id}
                    className="p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-start gap-4">
                      {report.imageUrl && (
                        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border border-slate-200 bg-white">
                          <img
                            src={report.imageUrl}
                            alt={report.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-[10px] text-slate-500 font-semibold bg-white px-2 py-0.5 rounded border border-slate-200">
                            {report.id}
                          </span>
                          {renderStatusBadge(report.status)}
                        </div>
                        <h4 className="text-sm font-bold text-[#112923] font-display truncate">
                          {report.title}
                        </h4>
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {report.description}
                        </p>
                      </div>
                    </div>

                    {/* Metadata & Verification Note */}
                    <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>{report.location}</span>
                      </div>
                      <span>{report.dateReported}</span>
                    </div>

                    {report.aiExplanation && (
                      <div className="p-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200/70 text-[11px] text-emerald-800 flex items-start gap-2">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{report.aiExplanation}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center space-y-3">
                <FileText className="w-10 h-10 text-slate-300 mx-auto" />
                <h4 className="text-sm font-bold text-slate-800">No lost reports filed</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  If you misplaced anything on campus grounds, submit a lost report to notify the security custody desks.
                </p>
                <button
                  onClick={() => onNavigateToReport('lost')}
                  className="px-4 py-2 bg-[#112923] text-white text-xs font-semibold rounded-xl"
                >
                  Report Lost Item
                </button>
              </div>
            )}
          </div>
        )}

        {/* SECTION 2: MY FOUND REPORTS */}
        {activeSection === 'found' && (
          <div className="space-y-4">
            {myFoundReports.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myFoundReports.map((report) => (
                  <div
                    key={report.id}
                    className="p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 transition-all flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-start gap-4">
                      {report.imageUrl && (
                        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border border-slate-200 bg-white">
                          <img
                            src={report.imageUrl}
                            alt={report.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-[10px] text-slate-500 font-semibold bg-white px-2 py-0.5 rounded border border-slate-200">
                            {report.id}
                          </span>
                          {renderStatusBadge(report.status)}
                        </div>
                        <h4 className="text-sm font-bold text-[#112923] font-display truncate">
                          {report.title}
                        </h4>
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {report.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>Found at: {report.location}</span>
                      </div>
                      <span>{report.dateReported}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-slate-300 mx-auto" />
                <h4 className="text-sm font-bold text-slate-800">No found reports submitted</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  When you pick up a lost belonging, drop it at the nearest security desk or log it in inventory so the rightful owner can recover it.
                </p>
              </div>
            )}
          </div>
        )}

        {/* SECTION 3: MY RECOVERY REQUESTS */}
        {activeSection === 'claims' && (
          <div className="space-y-4">
            {claims.length > 0 ? (
              <div className="space-y-3">
                {claims.map((claim) => (
                  <div
                    key={claim.id}
                    className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-white transition-all space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] font-bold text-[#112923] bg-white px-2.5 py-0.5 rounded border border-slate-200">
                            {claim.id}
                          </span>
                          <span className="text-xs text-slate-400">•</span>
                          <span className="text-xs text-slate-500">Claimed {claim.requestDate}</span>
                        </div>
                        <h4 className="text-sm font-bold text-[#112923] font-display">
                          {claim.itemTitle}
                        </h4>
                      </div>

                      <div>{renderStatusBadge(claim.status)}</div>
                    </div>

                    {claim.instructions && (
                      <div className="p-3 rounded-xl bg-blue-50 border border-blue-200/80 text-xs text-blue-900 space-y-1">
                        <div className="font-semibold flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-blue-700" />
                          <span>Pickup Location: {claim.pickupLocation}</span>
                        </div>
                        <p className="text-[11px] text-blue-700 leading-relaxed">
                          {claim.instructions}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center space-y-3">
                <ShieldCheck className="w-10 h-10 text-slate-300 mx-auto" />
                <h4 className="text-sm font-bold text-slate-800">No active recovery requests</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Browse the campus inventory to locate your misplaced items and submit an ownership verification claim.
                </p>
                <button
                  onClick={onNavigateToInventory}
                  className="px-4 py-2 bg-[#112923] text-white text-xs font-semibold rounded-xl"
                >
                  Browse Campus Inventory
                </button>
              </div>
            )}
          </div>
        )}

      </div>

      {/* ========================================================
          EDIT PROFILE MODAL
         ======================================================== */}
      {editModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
            
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-[#f8faf6]">
              <div>
                <h3 className="text-base font-bold text-[#112923] font-display">
                  Edit Student Profile
                </h3>
                <p className="text-xs text-slate-500">
                  Update your contact and institutional college details.
                </p>
              </div>
              <button
                onClick={() => setEditModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveProfile} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Full Name</label>
                <input
                  type="text"
                  value={editForm.name || ''}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Student ID</label>
                  <input
                    type="text"
                    value={editForm.studentId || ''}
                    onChange={(e) => setEditForm({ ...editForm, studentId: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Phone Number</label>
                  <input
                    type="tel"
                    value={editForm.phone || ''}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Campus Email</label>
                <input
                  type="email"
                  value={editForm.email || ''}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">College / Institution</label>
                <input
                  type="text"
                  value={editForm.college || ''}
                  onChange={(e) => setEditForm({ ...editForm, college: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Department</label>
                <input
                  type="text"
                  value={editForm.department || ''}
                  onChange={(e) => setEditForm({ ...editForm, department: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Division</label>
                  <input
                    type="text"
                    value={editForm.division || ''}
                    onChange={(e) => setEditForm({ ...editForm, division: e.target.value })}
                    placeholder="e.g. Div A"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Roll Number</label>
                  <input
                    type="text"
                    value={editForm.rollNumber || ''}
                    onChange={(e) => setEditForm({ ...editForm, rollNumber: e.target.value })}
                    placeholder="e.g. CE-42"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Bio / Campus Note</label>
                <textarea
                  rows={2}
                  value={editForm.bio || ''}
                  onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#112923]/30"
                />
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProfile}
                  className="px-5 py-2 font-bold text-white bg-[#112923] hover:bg-[#1a4037] rounded-xl transition-all shadow-xs disabled:opacity-50"
                >
                  {savingProfile ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ========================================================
          LOGOUT CONFIRMATION MODAL
         ======================================================== */}
      {logoutModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <LogOut className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900 font-display">
                Sign Out of Campus Network?
              </h3>
              <p className="text-xs text-slate-500">
                You will need to sign in again to file reports or manage recovery claims.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setLogoutModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Stay Signed In
              </button>
              <button
                onClick={handleConfirmLogout}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
