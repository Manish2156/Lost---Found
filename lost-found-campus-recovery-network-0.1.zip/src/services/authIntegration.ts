/**
 * Campus Lost & Found — Authentication & Profile Integration Service
 * 
 * INTEGRATION INTERFACE CONTRACT FOR AUTH TEAM:
 * Your authentication service (Login, Sign In, Sign Up) can integrate seamlessly
 * with this Profile & Dashboard layer by calling any of these standard methods:
 * 
 * 1. Store auth session:
 *    localStorage.setItem('campus_auth_user', JSON.stringify(userData));
 *    window.dispatchEvent(new Event('campus-auth-change'));
 * 
 * 2. Or call helper directly:
 *    import { setAuthSession } from '@/services/authIntegration';
 *    setAuthSession(token, userProfile);
 * 
 * 3. Logout handler:
 *    logoutUser(); // Clears session and notifies listeners
 */

import { UserProfile, UserReportItem, UserRecoveryRequest } from '../types';

const AUTH_STORAGE_KEY = 'campus_auth_user';
const PROFILE_STORAGE_KEY = 'campus_user_profile';
const TOKEN_STORAGE_KEY = 'campus_auth_token';

// Default Student Profile used as initial active session
export const DEFAULT_STUDENT_PROFILE: UserProfile = {
  id: 'STU-2026-8842',
  name: 'Raj Vishwakarma',
  email: 'raj.vishwakarma@campus.edu',
  studentId: 'STU-884291',
  college: 'Campus College of Science & Arts',
  department: 'Computer Engineering & Technology',
  division: 'Div A',
  rollNumber: 'CE-42',
  phone: '+91 98765 43210',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  bio: 'Third-year engineering student. Tech enthusiast & campus recovery volunteer.',
  joinedDate: 'August 2024',
  status: 'Active Student'
};

export const INITIAL_USER_REPORTS: UserReportItem[] = [
  {
    id: 'LF-2026-9041',
    title: 'Boat Rockerz 450 Bluetooth Headphones',
    type: 'lost',
    category: 'Electronics',
    location: 'Sci building',
    dateReported: 'Yesterday at 3:30 PM',
    status: 'Pending',
    description: 'Matte black finish with slight scratch on left hinge.',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
    aiVerificationStatus: 'verified',
    aiExplanation: 'AI Vision confirmed image shows black wireless headphones matching description.'
  },
  {
    id: 'LF-2026-8812',
    title: 'Graphing Calculator (TI-84 Plus CE)',
    type: 'lost',
    category: 'Electronics',
    location: 'Comm building',
    dateReported: '4 days ago',
    status: 'Approved',
    description: 'Blue casing with sticker on the battery cover.',
    imageUrl: 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?auto=format&fit=crop&w=600&q=80',
    aiVerificationStatus: 'verified',
    aiExplanation: 'AI Vision verified scientific graphing calculator.'
  },
  {
    id: 'LF-2026-7734',
    title: 'Casio Vintage Digital Watch (Silver)',
    type: 'found',
    category: 'Jewelry & Accessories',
    location: 'Canteen',
    dateReported: '1 week ago',
    status: 'Recovered',
    description: 'Found on table 4 near the refreshment counter.',
    imageUrl: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80',
    aiVerificationStatus: 'verified',
    aiExplanation: 'AI Vision confirmed image shows metallic wrist watch.'
  }
];

export const INITIAL_USER_CLAIMS: UserRecoveryRequest[] = [
  {
    id: 'CLM-2026-104',
    itemId: 'LF-2026-8812',
    itemTitle: 'Graphing Calculator (TI-84 Plus CE)',
    location: 'Comm building',
    requestDate: '3 days ago',
    status: 'Approved',
    pickupLocation: 'Front gate security office',
    instructions: 'Please bring your valid student ID card for physical custody verification.'
  },
  {
    id: 'CLM-2026-108',
    itemId: 'LF-2026-9041',
    itemTitle: 'Boat Rockerz 450 Bluetooth Headphones',
    location: 'Sci building',
    requestDate: 'Yesterday',
    status: 'Pending',
    pickupLocation: 'Sci building custody desk',
    instructions: 'Staff is currently verifying serial details with the finder.'
  }
];

/**
 * Retrieves the current authenticated student profile.
 * Falls back to local storage or the default student session.
 */
export async function getStudentProfile(): Promise<{
  profile: UserProfile;
  reports: UserReportItem[];
  claims: UserRecoveryRequest[];
}> {
  // First attempt to load from backend API if available
  try {
    const res = await fetch('/api/user/profile');
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.profile) {
        // Cache to localStorage
        localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(data.profile));
        return {
          profile: data.profile,
          reports: data.reports || INITIAL_USER_REPORTS,
          claims: data.claims || INITIAL_USER_CLAIMS
        };
      }
    }
  } catch (_e) {
    // Network / offline fallback
  }

  // Fallback to localStorage
  const cached = localStorage.getItem(PROFILE_STORAGE_KEY) || localStorage.getItem(AUTH_STORAGE_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      return {
        profile: { ...DEFAULT_STUDENT_PROFILE, ...parsed },
        reports: INITIAL_USER_REPORTS,
        claims: INITIAL_USER_CLAIMS
      };
    } catch (_e) {
      // Ignore parse error
    }
  }

  return {
    profile: DEFAULT_STUDENT_PROFILE,
    reports: INITIAL_USER_REPORTS,
    claims: INITIAL_USER_CLAIMS
  };
}

/**
 * Updates profile details both locally and via backend API.
 */
export async function updateStudentProfile(updates: Partial<UserProfile>): Promise<UserProfile> {
  // Update via backend API
  try {
    const res = await fetch('/api/user/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (res.ok) {
      const data = await res.json();
      if (data.profile) {
        localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(data.profile));
        return data.profile;
      }
    }
  } catch (_e) {
    // Backend offline; persist locally
  }

  const existingRaw = localStorage.getItem(PROFILE_STORAGE_KEY);
  const existing = existingRaw ? JSON.parse(existingRaw) : DEFAULT_STUDENT_PROFILE;
  const updated = { ...existing, ...updates };
  localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(updated));
  return updated;
}

/**
 * Sets authenticated session token and profile (called by Login/Register page)
 */
export function setAuthSession(token: string, user: Partial<UserProfile>) {
  localStorage.setItem(TOKEN_STORAGE_KEY, token);
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
  localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(user));
  window.dispatchEvent(new Event('campus-auth-change'));
}

/**
 * Logs out the user session cleanly without disrupting the frontend
 */
export function logoutUser(): void {
  localStorage.removeItem(TOKEN_STORAGE_KEY);
  localStorage.removeItem(AUTH_STORAGE_KEY);
  window.dispatchEvent(new Event('campus-auth-logout'));
}
