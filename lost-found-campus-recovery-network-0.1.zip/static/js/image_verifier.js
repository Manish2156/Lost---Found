/**
 * LOST & FOUND — CAMPUS RECOVERY NETWORK
 * Task 2: AI-Powered Image Verification Controller
 * 
 * Flow:
 * 1. User picks/drags image.
 * 2. Preview is rendered instantly.
 * 3. User triggers "Verify Photo with AI" (or runs automatically).
 * 4. Image + item metadata sent to Flask `/api/verify-image`.
 * 5. Gemini Vision response parsed and badge updated (Verified, Needs Review, Mismatch).
 * 6. If mismatch, warns user and suggests correction.
 */

document.addEventListener('DOMContentLoaded', () => {
    const dropzone = document.getElementById('dropzone');
    const imageInput = document.getElementById('imageInput');
    const uploadPrompt = document.getElementById('uploadPrompt');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const removeImageBtn = document.getElementById('removeImageBtn');

    const verifyBtn = document.getElementById('verifyBtn');
    const verifyBtnText = document.getElementById('verifyBtnText');
    const verifySpinner = document.getElementById('verifySpinner');

    const aiResultBox = document.getElementById('aiResultBox');
    const resultBadge = document.getElementById('resultBadge');
    const resultExplanation = document.getElementById('resultExplanation');
    const aiVerificationStatus = document.getElementById('aiVerificationStatus');

    const titleInput = document.getElementById('title');
    const categorySelect = document.getElementById('category');
    const descriptionText = document.getElementById('description');
    const submitBtn = document.getElementById('submitReportBtn');

    let currentFile = null;

    if (!imageInput) return;

    // 1. FILE PICKER & DRAG/DROP
    imageInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
            handleFileSelect(e.target.files[0]);
        }
    });

    if (dropzone) {
        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                dropzone.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                dropzone.classList.remove('dragover');
            });
        });

        dropzone.addEventListener('drop', (e) => {
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                imageInput.files = e.dataTransfer.files;
                handleFileSelect(e.dataTransfer.files[0]);
            }
        });
    }

    function handleFileSelect(file) {
        // Validate file type
        const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            alert('Please select a valid image file (PNG, JPG, or WEBP).');
            return;
        }

        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert('File size exceeds 5MB limit. Please choose a smaller photo.');
            return;
        }

        currentFile = file;

        // Render preview
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.src = e.target.result;
            uploadPrompt.classList.add('d-none');
            imagePreviewContainer.classList.remove('d-none');
            if (verifyBtn) {
                verifyBtn.disabled = false;
            }
        };
        reader.readAsDataURL(file);

        // Reset previous result
        if (aiResultBox) {
            aiResultBox.classList.add('d-none');
        }
        if (aiVerificationStatus) {
            aiVerificationStatus.value = 'unverified';
        }
    }

    // REMOVE IMAGE
    if (removeImageBtn) {
        removeImageBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            currentFile = null;
            imageInput.value = '';
            imagePreview.src = '';
            imagePreviewContainer.classList.add('d-none');
            uploadPrompt.classList.remove('d-none');
            if (verifyBtn) verifyBtn.disabled = true;
            if (aiResultBox) aiResultBox.classList.add('d-none');
            if (aiVerificationStatus) aiVerificationStatus.value = 'unverified';
        });
    }

    // 2. TRIGGER AI VISION VERIFICATION VIA FLASK BACKEND
    if (verifyBtn) {
        verifyBtn.addEventListener('click', async () => {
            if (!currentFile) return;

            const titleVal = titleInput ? titleInput.value.trim() : '';
            const categoryVal = categorySelect ? categorySelect.value : '';
            const descVal = descriptionText ? descriptionText.value.trim() : '';

            if (!titleVal) {
                alert('Please enter an Item Title before verifying the photo with AI.');
                if (titleInput) titleInput.focus();
                return;
            }

            // Set loading state
            verifyBtn.disabled = true;
            verifyBtnText.textContent = 'Analyzing Photo...';
            verifySpinner.classList.remove('d-none');

            const formData = new FormData();
            formData.append('image', currentFile);
            formData.append('title', titleVal);
            formData.append('category', categoryVal);
            formData.append('description', descVal);

            try {
                const response = await fetch('/api/verify-image', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                renderVerificationResult(data.status, data.explanation);

            } catch (err) {
                renderVerificationResult('needs_review', 'Verification service reached timeout. Report flagged for campus coordinator review.');
            } finally {
                verifyBtn.disabled = false;
                verifyBtnText.textContent = 'Verify Photo with AI';
                verifySpinner.classList.add('d-none');
            }
        });
    }

    function renderVerificationResult(status, explanation) {
        if (!aiResultBox || !resultBadge || !resultExplanation) return;

        aiResultBox.classList.remove('d-none');
        resultExplanation.textContent = explanation;
        aiVerificationStatus.value = status;

        resultBadge.className = 'result-badge';
        if (status === 'verified') {
            resultBadge.classList.add('verified');
            resultBadge.textContent = '✓ Verified / Relevant';
            if (submitBtn) submitBtn.disabled = false;
        } else if (status === 'needs_review') {
            resultBadge.classList.add('needs_review');
            resultBadge.textContent = '⚠ Needs Review (Sent for Moderation)';
            if (submitBtn) submitBtn.disabled = false;
        } else if (status === 'mismatch') {
            resultBadge.classList.add('mismatch');
            resultBadge.textContent = '✕ Mismatch Detected';
            // Warn user and advise correction
            alert('AI Vision detected a mismatch between this image and your item title. Please upload a matching photo.');
        }
    }
});
