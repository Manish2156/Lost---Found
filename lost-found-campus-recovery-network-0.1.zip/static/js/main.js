/**
 * LOST & FOUND — CAMPUS RECOVERY NETWORK
 * Vanilla JavaScript Controller (Task 3: Mobile Navigation Drawer)
 */

document.addEventListener('DOMContentLoaded', () => {
    // -------------------------------------------------------------
    // TASK 3: RIGHT-SIDE OFF-CANVAS MOBILE DRAWER CONTROLLER
    // -------------------------------------------------------------
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeDrawerBtn = document.getElementById('closeDrawerBtn');
    const mobileDrawer = document.getElementById('mobileDrawer');
    const drawerBackdrop = document.getElementById('drawerBackdrop');

    function openDrawer() {
        if (!mobileDrawer || !drawerBackdrop) return;
        mobileDrawer.classList.add('active');
        drawerBackdrop.classList.add('active');
        // Prevent background scrolling while drawer is active
        document.body.style.overflow = 'hidden';
    }

    function closeDrawer() {
        if (!mobileDrawer || !drawerBackdrop) return;
        mobileDrawer.classList.remove('active');
        drawerBackdrop.classList.remove('active');
        // Restore natural background scrolling
        document.body.style.overflow = '';
    }

    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            openDrawer();
        });
    }

    if (closeDrawerBtn) {
        closeDrawerBtn.addEventListener('click', closeDrawer);
    }

    if (drawerBackdrop) {
        drawerBackdrop.addEventListener('click', closeDrawer);
    }

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeDrawer();
        }
    });

    // Close drawer on link selection
    const drawerLinks = document.querySelectorAll('.drawer-link, .drawer-btn-contact');
    drawerLinks.forEach(link => {
        link.addEventListener('click', closeDrawer);
    });

    // -------------------------------------------------------------
    // AUTO-DISMISS FLASH NOTIFICATIONS
    // -------------------------------------------------------------
    const flashAlerts = document.querySelectorAll('.flash-alert');
    flashAlerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-6px)';
            setTimeout(() => alert.remove(), 400);
        }, 5000);
    });
});
